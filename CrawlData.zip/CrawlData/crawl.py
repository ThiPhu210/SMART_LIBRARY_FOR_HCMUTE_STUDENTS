import os
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import WebDriverException

# Thư mục gốc để lưu các file PDF
base_output_folder = "PDFBooks"
if not os.path.exists(base_output_folder):
    os.makedirs(base_output_folder)

# URL của trang web chứa danh sách các khoa
categories_url = "https://thuvienso.hcmute.edu.vn"

# Headers để giả lập trình duyệt
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}

# Hàm để tải file PDF
def download_pdf(pdf_url, book_title, output_folder):
    try:
        pdf_response = requests.get(pdf_url, headers=headers, stream=True)
        if pdf_response.status_code == 200:
            # Tạo tên file từ tiêu đề sách
            safe_title = "".join(c if c.isalnum() else "_" for c in book_title)
            pdf_filename = os.path.join(output_folder, f"{safe_title}.pdf")

            # Lưu file PDF
            with open(pdf_filename, "wb") as pdf_file:
                for chunk in pdf_response.iter_content(chunk_size=1024):
                    if chunk:
                        pdf_file.write(chunk)
            print(f"Đã tải: {book_title} -> {pdf_filename}")
        else:
            print(f"Không thể tải PDF từ {pdf_url}. Status code: {pdf_response.status_code}")
    except Exception as e:
        print(f"Lỗi khi tải PDF: {e}")

# Hàm để crawl dữ liệu từ một URL cụ thể
def crawl_category(category_url, category_name):
    # Tạo thư mục cho khoa
    output_folder = os.path.join(base_output_folder, category_name)
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Đường dẫn đến ChromeDriver
    chromedriver_path = "chromedriver/chromedriver-win64/chromedriver.exe"  # Thay đổi đường dẫn nếu cần

    # Khởi tạo trình duyệt Selenium
    try:
        service = Service(executable_path=chromedriver_path)
        driver = webdriver.Chrome(service=service)
    except WebDriverException as e:
        print(f"Lỗi khi khởi tạo trình duyệt Chrome: {e}")
        return

    try:
        page = 20
        while True:
            # Tạo URL động
            search_url = f"{category_url}?vt=moinhat&ft=all&fft=all&fl=all&catetl=0&subcatetl=0&page={page}"
            print(f"\nĐang xử lý trang {page} của khoa {category_name}: {search_url}")

            # Truy cập trang
            driver.get(search_url)
            html = driver.page_source
            soup = BeautifulSoup(html, "html.parser")

            # Tìm tất cả các thẻ <li> chứa thông tin sách
            books = soup.select("#box_search_book_result > ul > li")

            # Nếu không có sách trên trang hiện tại, dừng vòng lặp
            if not books:
                print(f"Không tìm thấy sách trên trang {page}. Kết thúc crawl cho khoa {category_name}.")
                break

            # Xử lý từng sách
            for book in books:
                # Lấy tiêu đề sách và URL chi tiết
                title_tag = book.select_one("p.title_book > a")
                if title_tag:
                    book_title = title_tag.get("title", "Không có tiêu đề")
                    book_url = title_tag.get("href", "")
                else:
                    print("Không tìm thấy thẻ tiêu đề sách.")
                    continue

                # Kiểm tra xem URL có hợp lệ không
                if not book_url:
                    print(f"Không tìm thấy URL cho sách: {book_title}")
                    continue

                # Tạo URL đầy đủ
                book_url = urljoin(categories_url, book_url)

                print(f"\nĐang xử lý sách: {book_title}")
                print(f"URL chi tiết: {book_url}")

                # Truy cập vào trang chi tiết sách bằng Selenium
                try:
                    driver.get(book_url)
                    html = driver.page_source
                    book_soup = BeautifulSoup(html, "html.parser")

                    # Tìm thẻ <div id="flash_book"> chứa thẻ <embed>
                    flash_book = book_soup.find("div", id="flash_book")
                    if flash_book:
                        embed_tag = flash_book.find("embed")
                        if embed_tag:
                            pdf_url = embed_tag.get("src")
                            if pdf_url:
                                print(f"URL PDF: {pdf_url}")
                                download_pdf(pdf_url, book_title, output_folder)
                            else:
                                print(f"Không tìm thấy URL PDF trong thẻ <embed>.")
                        else:
                            print(f"Không tìm thấy thẻ <embed> trong trang: {book_title}")
                    else:
                        print(f"Không tìm thấy thẻ <div id='flash_book'> trong trang: {book_title}")
                except Exception as e:
                    print(f"Lỗi khi xử lý trang chi tiết: {e}")

            # Tăng số trang
            page += 1

            # Giới hạn số trang tối đa (ví dụ: 20 trang)
            if page > 50:
                print(f"Đã đạt đến giới hạn số trang (20 trang) cho khoa {category_name}.")
                break
    finally:
        # Đóng trình duyệt Selenium
        driver.quit()
        print(f"\nTrình duyệt đã đóng cho khoa {category_name}.")

# Lấy nội dung HTML của trang danh mục
try:
    response = requests.get(categories_url, headers=headers)
    response.raise_for_status()  # Kiểm tra lỗi HTTP
    print(f"Status code (trang danh mục): {response.status_code}")
except requests.exceptions.RequestException as e:
    print(f"Lỗi khi truy cập trang danh mục: {e}")
    exit()

soup = BeautifulSoup(response.text, "html.parser")

# Tìm tất cả các thẻ <a> chứa liên kết đến các khoa
category_links = soup.select("div.catetruong ul.content_cate li a")

# Danh sách các khoa cần crawl
target_categories = [
    # "Cơ khí chế tạo máy",
    # "Điện - Điện tử",
    # "Cơ khí động lực",
    # "Xây dựng - Kiến trúc",
    "CN Thực phẩm - Môi trường",
    "Công nghệ thông tin",
    "Kinh tế - Quản lý",
    "CN In - Truyền thông",
    "CN May - thời trang",
    "Nghệ thuật - Ẩm thực",
    "Nông - Lâm - Ngư  Nghiệp",
    "Y học - Sức khỏe",
    "Khoa học xã hội",
    "Lịch sử -  Địa lý -  Du lịch",
    "Khoa học tự nhiên",
    "Văn học",
    "Ngôn ngữ",
    "Kỹ thuật - Khoa học ứng dụng",
]

# Lặp qua từng liên kết và crawl dữ liệu
for link in category_links:
    category_name = link.find("span", id="refontcate").text.strip()
    
    # Chỉ crawl các khoa trong danh sách target_categories
    if category_name in target_categories:
        category_url = urljoin(categories_url, link.get("href"))
        print(f"\nĐang xử lý khoa: {category_name}")
        print(f"URL khoa: {category_url}")

        # Crawl dữ liệu từ khoa này
        crawl_category(category_url, category_name)

print("\nHoàn tất quá trình tải xuống.")